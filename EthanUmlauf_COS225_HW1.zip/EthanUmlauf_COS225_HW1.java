
public class EthanUmlauf_COS225_HW1{
    public static void main(String[]args){
        System.out.print("Hello");
        System.out.print(" Ethan Umlauf");

    }
}